/*
 * Filtrado_y_ponderacion_max4466_types.h
 *
 * Code generation for model "Filtrado_y_ponderacion_max4466".
 *
 * Model version              : 1.15
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Mon Apr  3 17:36:51 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Filtrado_y_ponderacion_max4466_types_h_
#define RTW_HEADER_Filtrado_y_ponderacion_max4466_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_Filtrado_y_ponderacion_max4_T_ P_Filtrado_y_ponderacion_max4_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Filtrado_y_ponderacio_T RT_MODEL_Filtrado_y_ponderaci_T;

#endif                  /* RTW_HEADER_Filtrado_y_ponderacion_max4466_types_h_ */
